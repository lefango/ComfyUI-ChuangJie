"""Standalone experiment; does not register or modify the original modules."""
from .core import (VERSION, MANAGER, ASSET, PATCH, TRIGGERS, PROMPT_STAGE,
                   EDIT_IMAGE_STAGE, MASK_COMPOSITE_STAGE)
from .runtime import (UnifiedManager, AssetLoader, LoRAStage, TriggerStage,
                      PromptStage, EditImageStage, MaskCompositeStage, compile_prompt)

__version__ = VERSION
NODE_CLASS_MAPPINGS = {MANAGER: UnifiedManager, ASSET: AssetLoader, PATCH: LoRAStage,
                       TRIGGERS: TriggerStage, PROMPT_STAGE: PromptStage,
                       EDIT_IMAGE_STAGE: EditImageStage, MASK_COMPOSITE_STAGE: MaskCompositeStage}
NODE_DISPLAY_NAME_MAPPINGS = {MANAGER: "创界集成控制台", ASSET: "一体节点 · 内部加载",
                            PATCH: "一体节点 · 内部 LoRA", TRIGGERS: "一体节点 · 内部触发词",
                            PROMPT_STAGE: "一体节点 · 内部提示词", EDIT_IMAGE_STAGE: "一体节点 · 内部图像编辑",
                            MASK_COMPOSITE_STAGE: "一体节点 · 内部遮罩合成"}
WEB_DIRECTORY = "./web"


def register():
    import folder_paths
    from server import PromptServer
    server = PromptServer.instance
    if server is None or getattr(server, "_cj_unified_test_registered", False):
        return
    from .model.api import register as register_models
    from .lora.api import register as register_loras
    from .api import register as register_suite
    register_models(server, folder_paths)
    register_loras()
    register_suite(server, folder_paths)
    server.add_on_prompt_handler(compile_prompt)
    server._cj_unified_test_registered = True


register()
